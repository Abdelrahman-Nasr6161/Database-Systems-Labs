#!/bin/zsh
# Run two Python scripts sequentially

echo "Running first script..."
python3 task2.py

echo "Running second script..."
python3 task1.py

echo "All scripts completed successfully!"
